const express=require("express"), session=require("express-session"), path=require("path"), Database=require("better-sqlite3");
const app=express(), db=new Database("carshenas.db");
app.use(express.json({limit:"1mb"}));
app.use(session({secret:process.env.SESSION_SECRET||"change-this-secret",resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:"lax"}}));
app.use(express.static(path.join(__dirname,"public")));
db.exec(`CREATE TABLE IF NOT EXISTS cars(id INTEGER PRIMARY KEY AUTOINCREMENT,brand TEXT NOT NULL,model TEXT NOT NULL,year TEXT,description TEXT,image TEXT);`);
if(db.prepare("SELECT COUNT(*) n FROM cars").get().n===0){
 const add=db.prepare("INSERT INTO cars(brand,model,year,description,image) VALUES(?,?,?,?,?)");
 [["BMW","M4 Competition","2025","کوپه اسپرت و قدرتمند","https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=1000&q=85"],
 ["Mercedes-Benz","AMG GT","2025","کوپه لوکس و اسپرت","https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&w=1000&q=85"],
 ["Porsche","911 Carrera","2025","یکی از شناخته‌شده‌ترین خودروهای اسپرت","https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1000&q=85"],
 ["Toyota","GR Supra","2025","خودروی اسپرت ژاپنی","https://images.unsplash.com/photo-1614200187524-dc4b892acf16?auto=format&fit=crop&w=1000&q=85"],
 ["Nissan","GT-R","2025","اسپرت افسانه‌ای ژاپن","https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=1000&q=85"]].forEach(x=>add.run(...x));
}
const admin=(req,res,next)=>req.session.admin?next():res.status(401).json({error:"UNAUTHORIZED"});
app.get("/api/cars",(req,res)=>res.json(db.prepare("SELECT * FROM cars ORDER BY id DESC").all()));
app.post("/api/login",(req,res)=>{const pass=process.env.ADMIN_PASSWORD||"carshenas123";if(req.body.password===pass){req.session.admin=true;return res.json({ok:true})}res.status(401).json({error:"رمز اشتباه است"})});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",(req,res)=>res.json({admin:!!req.session.admin}));
app.post("/api/cars",admin,(req,res)=>{const {brand,model,year,description,image}=req.body;if(!brand||!model)return res.status(400).json({error:"برند و مدل الزامی است"});const r=db.prepare("INSERT INTO cars(brand,model,year,description,image) VALUES(?,?,?,?,?)").run(brand,model,year||"",description||"",image||"");res.json({id:r.lastInsertRowid})});
app.put("/api/cars/:id",admin,(req,res)=>{const {brand,model,year,description,image}=req.body;db.prepare("UPDATE cars SET brand=?,model=?,year=?,description=?,image=? WHERE id=?").run(brand,model,year||"",description||"",image||"",req.params.id);res.json({ok:true})});
app.delete("/api/cars/:id",admin,(req,res)=>{db.prepare("DELETE FROM cars WHERE id=?").run(req.params.id);res.json({ok:true})});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(process.env.PORT||3000,()=>console.log("CARSHENAS running"));
