CARSHENAS PRO
این نسخه یک سایت واقعی Node.js با دیتابیس SQLite و پنل مدیریت خصوصی است.

اجرای کامپیوتری:
1) Node.js نصب باشد.
2) داخل پوشه پروژه دستور npm install
3) سپس npm start
4) مرورگر: http://localhost:3000
5) پنل: http://localhost:3000/admin.html

برای امنیت قبل از انتشار:
متغیر محیطی ADMIN_PASSWORD را تعیین کن و SESSION_SECRET را هم تغییر بده.
برای آنلاین کردن، پروژه را روی یک سرویس Node.js مثل Render/Railway/Fly.io قرار بده و متغیرهای بالا را در تنظیمات سرویس وارد کن.
